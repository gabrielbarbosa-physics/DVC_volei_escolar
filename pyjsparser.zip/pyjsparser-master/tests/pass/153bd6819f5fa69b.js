({ yield() {} })
