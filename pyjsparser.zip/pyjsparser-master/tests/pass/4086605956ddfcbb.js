if (!a || b());
