(function () {
    void 1;
}());
