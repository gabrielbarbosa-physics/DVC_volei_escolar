(function () {
    -1;
}());
