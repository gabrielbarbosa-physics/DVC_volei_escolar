(yield) => 1;
