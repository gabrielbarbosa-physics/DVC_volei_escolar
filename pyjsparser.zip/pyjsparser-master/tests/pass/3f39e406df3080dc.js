a(...b, c, d);
