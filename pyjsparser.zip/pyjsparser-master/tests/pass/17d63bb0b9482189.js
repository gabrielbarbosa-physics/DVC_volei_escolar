var a = 'very cute';
