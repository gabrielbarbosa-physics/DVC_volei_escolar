class a { static *[b]() {} }
