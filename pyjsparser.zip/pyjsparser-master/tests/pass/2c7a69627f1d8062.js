while (a) {
    {
        b();
        b();
    }
}
