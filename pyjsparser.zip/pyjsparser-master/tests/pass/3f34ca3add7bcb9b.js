let [{a}] = 1
