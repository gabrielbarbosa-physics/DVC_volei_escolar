/**/ function a() {function b() {}}
