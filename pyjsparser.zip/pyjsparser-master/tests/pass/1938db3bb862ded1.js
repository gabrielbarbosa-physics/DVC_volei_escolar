function *a({yield: b}){}
