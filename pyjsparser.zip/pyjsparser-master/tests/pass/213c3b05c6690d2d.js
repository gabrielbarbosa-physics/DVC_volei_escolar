([yield] = a)
