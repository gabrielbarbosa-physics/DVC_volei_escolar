/**/ function a() {/**/function b() {}}
