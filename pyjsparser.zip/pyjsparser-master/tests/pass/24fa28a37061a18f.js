"use strict"; ({ yield() {} })
