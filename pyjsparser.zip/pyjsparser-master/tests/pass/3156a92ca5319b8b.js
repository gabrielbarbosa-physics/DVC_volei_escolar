throw 'a';
b();
