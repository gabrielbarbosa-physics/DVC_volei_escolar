let {a:{}} = 1
