do a()
;while (true)