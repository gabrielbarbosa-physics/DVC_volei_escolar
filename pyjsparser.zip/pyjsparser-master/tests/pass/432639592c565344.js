new a(...b);
