var { yield: a } = b;
