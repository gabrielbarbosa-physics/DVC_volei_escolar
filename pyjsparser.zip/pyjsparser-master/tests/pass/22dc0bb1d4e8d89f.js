function a({yield: b}){}
