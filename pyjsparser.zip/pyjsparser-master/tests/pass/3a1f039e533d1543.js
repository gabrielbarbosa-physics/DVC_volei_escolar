'use strict';
a.static();