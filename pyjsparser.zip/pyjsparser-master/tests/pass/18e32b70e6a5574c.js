Infinity.a();
NaN.a();