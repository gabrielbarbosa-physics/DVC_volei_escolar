let ℮
