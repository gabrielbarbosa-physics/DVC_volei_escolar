if (true) a()
; else;