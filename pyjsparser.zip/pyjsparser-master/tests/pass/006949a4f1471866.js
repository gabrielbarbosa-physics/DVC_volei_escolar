if (a) {
}
