if (a) {
} else {
    b();
}
