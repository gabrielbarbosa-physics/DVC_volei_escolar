let {a,} = 1
