function *a() { b.yield(); }
