a.in
{}
/foo/