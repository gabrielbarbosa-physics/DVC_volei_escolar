void ('a' + 'a')
